const express = require('express');
const app = express();
const http = require('http').Server(app);
const io = require('socket.io')(http);

app.use(express.static('public'));

app.get('/group-chat', function(req, res) {
    res.render('index.ejs');
});

app.get('/', function(req, res) {
    res.render('home.ejs');
});

app.get('/contact', function(req, res) {
    res.render('contact.ejs');
});

app.get('/get-started', function(req, res) {
    res.render('get-started.ejs');
});

app.get('/indexLogin', function(req, res) {
    res.render('indexLogin.ejs');
});

app.get('/thankyou', function(req, res) {
    res.render('thankyou.ejs');
});

app.get('/video-conf', function(req, res) {
    res.render('video-conf.ejs');
});

app.get('/chat-in-group', function(req, res) {
    res.render('chat-in-group.ejs');
});

app.get('/join-our-community', function(req, res) {
    res.render('join-our-community.ejs');
});



app.get('/about', function(req, res) {
    res.render('about.ejs');
});

io.sockets.on('connection', function(socket) {
    socket.on('username', function(username) {
        socket.username = username;
        io.emit('is_online', '🔵 <i>' + socket.username + ' join the chat..</i>');
    });

    socket.on('disconnect', function(username) {
        io.emit('is_online', '🔴 <i>' + socket.username + ' left the chat..</i>');
    })

    socket.on('chat_message', function(message) {
        io.emit('chat_message', '<strong>' + socket.username + '</strong>: ' + message);
    });

});

const server = http.listen(8080, function() {
    console.log('listening on *:8080');
});